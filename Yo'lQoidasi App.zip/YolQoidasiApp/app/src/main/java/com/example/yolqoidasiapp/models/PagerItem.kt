package com.example.yolqoidasiapp.models

data class PagerItem(
    var type: String,
    var typeInt: Int
)